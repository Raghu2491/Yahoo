//
//  ViewController.swift
//  Yahoo Finance
//
//  Created by Raghavendra Jayaramegowda on 2015/12/5.
//  Copyright © 2015 Raghavendra Jayaramegowda. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, NSXMLParserDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var searchTextField: UITextField!
    
    private var stocknames: [(String)] = [] //holds array of stock symbols e.g [AAPL,IBM]
    private var stockprices: [(String)] = [] //hold array of stock prices
    private var currentElement = "" // holds name of current XML element
    private var hasFound = false   // true if current element is "Symbol" or "Ask"
    
    @IBAction func buttonSearch(sender: AnyObject) {
        resignFirstResponder()
        self.updateStocks()
      
        
    }
    
    //Stock searching
    func updateStocks() {
        searchTextField.resignFirstResponder()
        let searchField = searchTextField.text
        let symbols = searchField?.characters.split(",").map(String.init)
        
        //if users input invalid value, show alert dialog
        if symbols!.isEmpty{
            let alert = UIAlertController(title: "Invalid Input", message: "Please input your stock symbols!", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            return
        }
        //build symbols characters from user input
        var query = ""
        for symbol in symbols! {
            query += "\"" + symbol + "\","
        }

        query.removeAtIndex(query.endIndex.predecessor()) //remove char "," at the last index
        
        //YAHOO Finance API: Request for a list of symbols example:
        //https://query.yahooapis.com/v1/public/yql?q=select * from yahoo.finance.quotes where symbol IN ("AAPL","GOOG","IBM")&format=json&env=http://datatables.org/alltables.env
        
        // build URL of XML document to be parser
        let url:String = "https://query.yahooapis.com/v1/public/yql?q=select * from yahoo.finance.quotes where symbol IN(" + query + ")&format=xml&env=http://datatables.org/alltables.env"
        //add space and special characters to url
        let urlStr:String = url.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)!
        
        let urlToSend = NSURL(string: urlStr as String)!
        
        // create a parser for the XML document
        let parser = NSXMLParser(contentsOfURL: urlToSend)!
        
        // set the delegate object to receive callbacks from the XML parser
        parser.delegate = self
        
        // parse the XML document (parse() returns true on success; false on encountering an error)
        let success = parser.parse()
        
        if success {
            print("\nPARSE SUCCESS! -----------------------------")
        } else{
            print("\nPARSE FAILURE! -----------------------------")
            let alert = UIAlertController(title: "Not Found", message: "Stock Symbol Not Found!", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            return
        }
        
        tableView.reloadData()
        NSLog("Symbols Values updated :)")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        currentElement = elementName
        
        if elementName == "Symbol"{
            hasFound = true
        } else if elementName == "Ask"{
            hasFound = true
        } else{
            hasFound = false
        }
        
    }
    
    func parser(parser: NSXMLParser, foundCharacters string: String) {
        if hasFound{
            if currentElement == "Symbol"{
                stocknames.append(string)
            } else if currentElement == "Ask"{
                stockprices.append(string)
            }
        }
    }
    
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        currentElement = ""
    }
    
    func parser(parser: NSXMLParser, parseErrorOccurred parseError: NSError) {
        NSLog("failure error: %@", parseError)
    }

    //update table row count
    func tableView(tableView: UITableView!, numberOfRowsInSection section: Int)  -> Int {
        return stocknames.count
    }
    
    //update table cells
    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell! {
    
        let cell:UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "cellId")
    
        cell.textLabel!.text = stocknames[indexPath.row]
        cell.detailTextLabel!.text = stockprices[indexPath.row]
    
        return cell
    }
}
